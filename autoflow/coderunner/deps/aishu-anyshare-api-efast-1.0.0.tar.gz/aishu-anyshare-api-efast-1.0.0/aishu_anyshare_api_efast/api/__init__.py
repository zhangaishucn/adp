# flake8: noqa

# import apis into api package
from aishu_anyshare_api_efast.api.default_api import DefaultApi
from aishu_anyshare_api_efast.api.shared_link_api import SharedLinkApi

