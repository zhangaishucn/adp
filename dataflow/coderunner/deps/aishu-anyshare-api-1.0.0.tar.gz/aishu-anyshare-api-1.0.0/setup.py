from setuptools import setup

NAME = 'aishu-anyshare-api'
VERSION = '1.0.0'
PYTHON_REQUIRES = ">=3.7"
REQUIRES=[
    "aishu-anyshare-api-efast",
    "aishu-anyshare-api-oauth2"
]

setup(
    name=NAME,
    version=VERSION,
    description="爱数 AnyShare 开放API",
    author="aishu.cn",
    author_email="",
    url="",
    keywords=["OpenAPI"],
    install_requires=REQUIRES,
    packages=["aishu_anyshare_api"],
    include_package_data=True,
    long_description_content_type='text/markdown',
    long_description="""\
    API to access AnyShare    如有任何疑问，可到开发者社区提问：https://developers.aishu.cn  # Authentication  - 调用需要鉴权的API，必须将token放在HTTP header中：\&quot;Authorization: Bearer ACCESS_TOKEN\&quot;  - 对于GET请求，除了将token放在HTTP header中，也可以将token放在URL query string中：\&quot;tokenid&#x3D;ACCESS_TOKEN\&quot;  
    """,  # noqa: E501
    package_data={"aishu_anyshare_api": ["py.typed"]},
)
