import aishu_anyshare_api_efast as efast
import aishu_anyshare_api_oauth2 as oauth2
import aishu_anyshare_api_doc_center as doc_center
import aishu_anyshare_api_metadata as metadata

HOST = ''
ACCESS_TOKEN = ''


class ApiClient:
    @staticmethod
    def set_global_host(host):
        global HOST
        HOST = host

    @staticmethod
    def get_global_host():
        return HOST

    @staticmethod
    def set_global_access_token(access_token):
        global ACCESS_TOKEN
        ACCESS_TOKEN = access_token

    @staticmethod
    def get_global_access_token():
        return ACCESS_TOKEN

    def __init__(self, host=None, access_token=None, verify_ssl=True):

        if host is None:
            host = HOST

        if access_token is None:
            access_token = ACCESS_TOKEN

        configuration = efast.Configuration(
            host='%s/%s' % (host, 'api'),
            access_token=access_token)

        configuration.verify_ssl = verify_ssl

        self.efast = efast.DefaultApi(api_client=efast.ApiClient(
            configuration=configuration
        ))

        configuration = oauth2.Configuration(
            host=host,
            access_token=access_token
        )

        configuration.verify_ssl = verify_ssl

        self.oauth2 = oauth2.DefaultApi(api_client=oauth2.ApiClient(
            configuration=configuration
        ))

        configuration = doc_center.Configuration(
            host=host,
            access_token=access_token
        )

        configuration.verify_ssl = verify_ssl

        self.doc_center = doc_center.DefaultApi(api_client=doc_center.ApiClient(
            configuration=configuration
        ))

        configuration = metadata.Configuration(
            host='%s/%s' % (host, 'api'),
            access_token=access_token
        )

        configuration.verify_ssl = verify_ssl

        self.metadata = metadata.DefaultApi(api_client=metadata.ApiClient(
            configuration=configuration
        ))
